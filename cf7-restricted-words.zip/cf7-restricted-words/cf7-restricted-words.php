<?php
/**
 * Plugin Name: CF7 Restricted Words & URL Blocker
 * Description: Block specific words and URLs in Contact Form 7 fields with live validation and admin settings.
 * Version: 1.0
 * Author: Digital Media Experts
 * License: GPL2
 */

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/*
|------------------------------------------------------------------
| 1. Admin Menu (Top-Level)
|------------------------------------------------------------------
*/
add_action('admin_menu', function() {
    add_menu_page(
        'Restricted Words Settings',
        'Restricted Words',
        'manage_options',
        'cf7-restricted-words',
        'cf7_restricted_words_page',
        'dashicons-shield',
        65
    );
});

/*
|------------------------------------------------------------------
| 2. Register the option for storing words
|------------------------------------------------------------------
*/
add_action('admin_init', function() {
    register_setting('cf7_restricted_words_group', 'cf7_restricted_words');
});

/*
|------------------------------------------------------------------
| 3. Admin page HTML
|------------------------------------------------------------------
*/
function cf7_restricted_words_page() {
    ?>
    <div class="wrap">
        <h1>CF7 Restricted Words Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('cf7_restricted_words_group');
            do_settings_sections('cf7_restricted_words_group');
            ?>
            <table class="form-table">
                <tr valign="top">
                    <th scope="row">Restricted Words</th>
                    <td>
                        <textarea name="cf7_restricted_words" rows="6" cols="60" placeholder="seo, guest post, guest posting, links, spanish"><?php echo esc_textarea(get_option('cf7_restricted_words', 'seo,guest post,guest posting,links,spanish')); ?></textarea>
                        
                    </td>
                </tr>
            </table>
            <?php submit_button('Save Restricted Words'); ?>
        </form>
    </div>
    <?php
}

/*
|------------------------------------------------------------------
| 4. Frontend JS + CSS for CF7 Validation
|------------------------------------------------------------------
*/
add_action('wp_enqueue_scripts', function() {
    if (!function_exists('wpcf7')) return; // Only if CF7 is active

    // Get restricted words from backend
    $restricted_words = get_option('cf7_restricted_words', 'seo,guest post,guest posting,links,spanish');
    $restricted_words_array = array_filter(array_map('trim', explode(',', $restricted_words)));

    // Register empty script and enqueue
    wp_register_script('cf7-restricted-js', false, array('contact-form-7'), null, true);
    wp_enqueue_script('cf7-restricted-js');

    // Localize data
    wp_localize_script('cf7-restricted-js', 'MY_CF7_RESTRICTED_DATA', array(
        'words' => $restricted_words_array,
        'generic_msg' => __('This field contains restricted content.', 'cf7-restricted'),
        'word_msg_prefix' => __('Restricted:', 'cf7-restricted'),
        'url_msg' => __('URLs are not allowed.', 'cf7-restricted'),
    ));

    // Inline JS
    $js = <<<JS
(function(){
    if (typeof window.MY_CF7_RESTRICTED_DATA === 'undefined') return;
    var data = window.MY_CF7_RESTRICTED_DATA;
    var restrictedWords = (data.words || []).map(function(w){ return String(w).toLowerCase(); });

    console.log('[CF7 Restricted] Loaded words:', restrictedWords);

    function escReg(str){ return str.replace(/[-/\\\\^$*+?.()|[\\]{}]/g, '\\\\$&'); }

    function findRestricted(value){
        var v = String(value);
        var vLower = v.toLowerCase();
        var hits = [];

        restrictedWords.forEach(function(word){
            if (!word) return;
            var pat = new RegExp('\\\\b' + escReg(word) + '\\\\b', 'i');
            if (pat.test(vLower)){
                hits.push(word);
            }
        });

        if (/(?:http:\\/\\/|https:\\/\\/|www\\.)/i.test(v)){
            hits.push('URL');
        }

        return hits;
    }

    function clearFieldError(field){
        field.classList.remove('restricted-field');
        var sib = field.nextSibling;
        while (sib) {
            if (sib.nodeType === 1 && sib.classList.contains('restricted-error')) {
                var rm = sib;
                sib = sib.nextSibling;
                rm.remove();
            } else {
                sib = sib.nextSibling;
            }
        }
    }

    function showFieldError(field, hits){
        field.classList.add('restricted-field');
        var msg;
        if (hits.length === 1 && hits[0] === 'URL') {
            msg = data.url_msg;
        } else {
            var wordsOnly = hits.filter(function(h){return h !== 'URL';});
            msg = data.generic_msg;
            if (wordsOnly.length) {
                msg = (data.word_msg_prefix || 'Restricted:') + ' ' + wordsOnly.join(', ');
            }
            if (hits.indexOf('URL') !== -1) {
                msg += ' ' + (data.url_msg || '(URL not allowed)');
            }
        }
        var span = document.createElement('span');
        span.className = 'restricted-error';
        span.style.color = 'red';
        span.style.fontSize = '12px';
        span.textContent = msg;
        field.insertAdjacentElement('afterend', span);
    }

    function validateForm(form){
        var bad = false;
        form.querySelectorAll('.restricted-error').forEach(function(e){ e.remove(); });
        form.querySelectorAll('.restricted-field').forEach(function(f){ f.classList.remove('restricted-field'); });
        var fields = form.querySelectorAll('input[type="text"], input[type="email"], textarea');
        fields.forEach(function(field){
            var hits = findRestricted(field.value);
            if (hits.length){
                bad = true;
                showFieldError(field, hits);
            }
        });
        return !bad;
    }

    document.addEventListener('submit', function(e){
        var form = e.target;
        if (!form.classList.contains('wpcf7-form')) return;
        if (!validateForm(form)){
            e.preventDefault();
            e.stopImmediatePropagation();
            var firstBad = form.querySelector('.restricted-field');
            if (firstBad) firstBad.focus();
        }
    }, true);

    document.addEventListener('input', function(e){
        var field = e.target;
        var form = field.closest && field.closest('.wpcf7-form');
        if (!form) return;
        clearFieldError(field);
        var hits = findRestricted(field.value);
        if (hits.length){
            showFieldError(field, hits);
        }
    });
})();
JS;
    wp_add_inline_script('cf7-restricted-js', $js);

    // Inline CSS
    $css = ".restricted-field{border:2px solid red !important;} .restricted-error{display:block;margin-top:4px;color:red;font-size:12px;}";
    wp_register_style('cf7-restricted-style', false);
    wp_enqueue_style('cf7-restricted-style');
    wp_add_inline_style('cf7-restricted-style', $css);
});
