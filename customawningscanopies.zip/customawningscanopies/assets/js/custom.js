jQuery(document).ready(function () {

  // === Sticky Header ===
  (function () {
    var shrinkHeader = 2;
    jQuery(window).scroll(function () {
      var scroll = window.pageYOffset || document.documentElement.scrollTop;
      if (scroll >= shrinkHeader) {
        jQuery('header.top-head').addClass('sticky');
      } else {
        jQuery('header.top-head').removeClass('sticky');
      }
    });
  })();

  // === Scroll to Top Button ===
  jQuery(window).on("scroll", function () {
    if (jQuery(this).scrollTop() > 100) {
      jQuery(".scrollup").addClass("actives");
    } else {
      jQuery(".scrollup").removeClass("actives");
    }
  });

  jQuery(".scrollup").on("click", function () {
    jQuery("html, body").animate({ scrollTop: 0 }, 600);
    return false;
  });

  // === AOS Animation ===
  AOS.init({
    once: true,
    throttleDelay: 0,
    offset: 0,
    disable: function () {
      return window.innerWidth < 768;
    }
  });

  let scrollRef = 0;
  window.addEventListener('scroll', function () {
    scrollRef <= 10 ? scrollRef++ : AOS.refresh();
  });

  // === Isotope Filtering ===
  var $grid = jQuery(".grid").isotope({
    itemSelector: ".all",
    percentPosition: true,
    masonry: {
      columnWidth: ".all"
    }
  });

  jQuery('.filters ul li').click(function () {
    jQuery('.filters ul li').removeClass('activefilter');
    jQuery(this).addClass('activefilter');
    var data = jQuery(this).attr('data-filter');
    $grid.isotope({ filter: data });
  });

  // === Swiper Sliders ===

  // Services Swiper
  new Swiper('.services-swiper', {
    slidesPerView: 4,
    loop: false,
    spaceBetween: 20,
    navigation: {
      nextEl: '.custom-next',
      prevEl: '.custom-prev',
    },
    breakpoints: {
      300: { slidesPerView: 1 },
      576: { slidesPerView: 2 },
      768: { slidesPerView: 2 },
      1020: { slidesPerView: 3 },
      1021: { slidesPerView: 4 }
    }
  });

  // Testimonial Swiper
  new Swiper('.testimonial-slider', {
    slidesPerView: 1,
    loop: true,
    spaceBetween: 30,
    navigation: {
      nextEl: '.testimonial-button-next',
      prevEl: '.testimonial-button-prev',
    }
  });

  // === Contact Form 7 – Hide Fields After Submit ===
  document.addEventListener('wpcf7mailsent', function () {
    document.querySelectorAll("form.wpcf7-form > :not(.wpcf7-response-output)").forEach(el => {
      el.style.display = 'none';
    });
  }, false);

  // === Form Label Animation ===
  jQuery('input, textarea').focus(function () {
    jQuery(this).parents('.form-group').addClass('focused');
  });

  jQuery('input, textarea').blur(function () {
    var inputValue = jQuery(this).val();
    if (inputValue === "") {
      jQuery(this).removeClass('filled');
      jQuery(this).parents('.form-group').removeClass('focused');
    } else {
      jQuery(this).addClass('filled');
    }
  });

  // === Mobile Menu Toggle ===
  let menu_icon_box = document.querySelector(".menu_icon_box");
  let box = document.querySelector(".box");

  menu_icon_box.onclick = function () {
    menu_icon_box.classList.toggle("activem");
    box.classList.toggle("active_box");
  };

  document.onclick = function (e) {
    if (!menu_icon_box.contains(e.target) && !box.contains(e.target)) {
      menu_icon_box.classList.remove("activem");
      box.classList.remove("active_box");
    }
  };

  // === Parallax Scroll Effect ===
  window.addEventListener("scroll", function () {
    const scrollY = window.scrollY;
    const topImg = document.querySelector(".bathcestop img");
    const bottomImg = document.querySelector(".bathces img");

    if (topImg) {
      topImg.style.transform = `translateY(${scrollY * 0.3}px)`;
    }

    if (bottomImg) {
      bottomImg.style.transform = `translateY(${scrollY * -0.3}px)`;
    }




  });





    // Service Slider
    new Swiper('.serviceSliderOuter .swiper', {
        paginationClickable: true,
        loop: true,
        spaceBetween: 50,
        slideToClickedSlide: true,
        // autoplay: {
        //     delay: 4000,
        //     disableOnInteraction: false,
        //     pauseOnMouseEnter: true,
        // },
        pagination: {
            el: '.serviceSliderOuter .swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            318: {
                slidesPerView: 1,
                spaceBetween: 20,
            },
            992: {
                slidesPerView: 4,
            },
        },
    });
    // Project Slider
    new Swiper('.projectSliderOuter .swiper', {
        slidesPerView: 4,
        paginationClickable: true,
        loop: true,
        spaceBetween: 30,
        slideToClickedSlide: true,
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
        },
        pagination: {
            el: '.projectSliderOuter .swiper-pagination',
            clickable: true,
        },
        breakpoints: {
            318: {
                slidesPerView: 1,
                spaceBetween: 20,
            },
            992: {
                slidesPerView: 3,
            },
            1280: {
                slidesPerView: 4,
            },
        },
    });
    // Showroom Slider
    new Swiper('.ourShowroomSlider .swiper', {
        slidesPerView: 1,
        loop: true,
        spaceBetween: 30,
        slideToClickedSlide: true,
        autoplay: {
            delay: 4000,
            disableOnInteraction: false,
            pauseOnMouseEnter: true,
        },
        pagination: {
            el: '.ourShowroomSlider .swiper-pagination',
            clickable: true,
        },
    });


//=======last braket=====
});


document.addEventListener("DOMContentLoaded", function () {
  const cards = document.querySelectorAll(".projects-holder");

  cards.forEach((card) => {
    card.addEventListener("click", function () {
      const group = card.getAttribute("data-group");

      // সব group-details hide করো
      document.querySelectorAll(".group-details").forEach((el) => {
        el.style.display = "none";
      });

      // clicked group-details দেখাও
      const detail = document.querySelector(`.group-details[data-group="${group}"]`);
      if (detail) {
        detail.style.display = "block";
      }

      // সব Swiper init আবারো করো (already init check করা যায়)
      const swiperContainer = detail.querySelector(`.swiper`);
      const swiperClass = swiperContainer.classList[1]; // e.g., swiper-0

      // Prevent multiple init
      if (!swiperContainer.classList.contains('swiper-initialized')) {
        new Swiper(`.${swiperClass}`, {
          loop: true,
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
          navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
          },
        });

        swiperContainer.classList.add('swiper-initialized');
      }
    });
  });
});
