<?php /* Template Name: Restaurant Template */ ?>

<?php get_header();?>

<section class="section sec-about">
  <div class="container">
    <div class="row">

      <div class="col-lg-6 col-12">
        <div class="page-content">
          <h2><?php the_field('about_title'); ?></h2>
         <?php the_field('about_content'); ?>
        </div>
      </div>

      <div class="col-lg-6 col-12">
        <div class="img-hoder">
          <?php 
            $image = get_field('about_image');
            if ($image): ?>
              <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
          <?php endif; ?>
        </div>
      </div>

    </div>
  </div>
</section>

<section class="section sec-project">
  <div class="container">
    <div class="row">
      <div class="heading-group">
        <h2>Projects</h2>
      </div>
    </div>


 <div class="row" id="cardWrapper">
  <?php if (have_rows('projects')): 
    $item_index = 0;
  ?>
    <?php while (have_rows('projects')): the_row(); 
      $title = get_sub_field('project_title');
      $desc = get_sub_field('project_short_description');
      $detail_text = get_sub_field('project_detail_text');
      $images = get_sub_field('project_gallery');
      $thumbnail = get_sub_field('thumbnail_image');
    ?>
      <div class="col-md-4">
        <div class="card item projects-holder" data-group="<?php echo $item_index; ?>">
          <?php if ($thumbnail): ?>
            <img src="<?php echo esc_url($thumbnail['url']); ?>" alt="<?php echo esc_attr($thumbnail['alt']); ?>" class="card-img-top">
          <?php endif; ?>
          <div class="card-body">
            <h3 class="card-title"><?php echo esc_html($title); ?></h3>
            <p class="card-text"><?php echo esc_html($desc); ?></p>
          </div>
        </div>
      </div>

      <!-- Details for each card -->
      <div class="col-12 group-details" data-group="<?php echo $item_index; ?>" style="display: none;">
        <div class="row align-items-center p-4 bg-light border rounded">
          <div class="col-md-6">
            <p><?php echo esc_html($detail_text); ?></p>
          </div>
          <div class="col-md-6">
            <div class="swiper swiper-<?php echo $item_index; ?>">
              <div class="swiper-wrapper">
                <?php if ($images): foreach ($images as $img): ?>
                  <div class="swiper-slide">
                    <img src="<?php echo esc_url($img['url']); ?>" alt="" class="img-fluid">
                  </div>
                <?php endforeach; endif; ?>
              </div>
              <div class="swiper-pagination"></div>
              <div class="swiper-button-next"></div>
              <div class="swiper-button-prev"></div>
            </div>
          </div>
        </div>
      </div>

      <?php $item_index++; ?>
    <?php endwhile; ?>
  <?php endif; ?>
</div>





  </div>
</section>



<?php get_footer();?>