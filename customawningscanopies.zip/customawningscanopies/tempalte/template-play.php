<?php
/* Template Name: Play Page */
get_header(); ?>



<?php get_footer(); ?>
