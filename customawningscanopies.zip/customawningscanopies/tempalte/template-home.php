<?php /* Template Name: Home Template */ ?>

<?php get_header();?>

<!-- modern-innovation -->
      <section class="modernInnovationWrapper section-padding">
  <div class="container">
    <div class="row">

      <div class="col-lg-6 col-md-12">
        <div class="modernInnovationPic">
          <?php 
            $modern_img = get_field('modern_image');
            if ($modern_img): 
          ?>
            <img src="<?php echo esc_url($modern_img['url']); ?>" alt="<?php echo esc_attr($modern_img['alt']); ?>">
          <?php endif; ?>
          
          <div class="modernInnovationBadge">
            <p>
              <?php the_field('badge_text'); ?>
              <strong><?php the_field('badge_year'); ?></strong>
            </p>
          </div>
        </div>
      </div>

      <div class="col-lg-6 col-md-12">
        <div class="section-heading">
          <h2><?php the_field('heading'); ?></h2>

          <div class="highlightText">
            <p><?php the_field('highlight_text'); ?></p>
          </div>

          <div class="descpText">
            <p><?php the_field('description_1'); ?></p>
            
          </div>

        </div>
      </div>

    </div>
  </div>
</section>

      <!-- modern-innovation -->


      <section class="ourServiceWrapper section-padding">
  <div class="container">
    <div class="section-heading text-center mb-50">
      <h2><?php the_field('section_title'); ?></h2>
    </div>
  </div>

  <div class="serviceSliderOuter">
    <div class="swiper">
      <div class="swiper-wrapper">
        <?php if( have_rows('services_list') ): ?>
          <?php while( have_rows('services_list') ): the_row(); 
            $image = get_sub_field('service_image');
            $title = get_sub_field('service_title');
            $description = get_sub_field('service_description');
            $link = get_sub_field('service_link');
          ?>
            <div class="swiper-slide">
              <div class="serviceSlideCard">
                <figure>
                  <?php if($image): ?>
                    <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($image['alt']); ?>">
                  <?php endif; ?>
                </figure>
                <div class="data">
                  <?php if($link): ?>
                    <a href="<?php echo esc_url($link); ?>">
                      <h3><?php echo esc_html($title); ?></h3>
                    </a>
                  <?php else: ?>
                    <h3><?php echo esc_html($title); ?></h3>
                  <?php endif; ?>
                  <p><?php echo esc_html($description); ?></p>
                </div>
              </div>
            </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </div>

    <!-- Add Pagination -->
    <div class="serviceSliderNav">
      <div class="swiper-pagination"></div>
    </div>
  </div>
</section>



    <section class="whyUsWrapper">
  <div class="whyUsPic">
    <?php 
      $whyus_img = get_field('whyus_image');
      if ($whyus_img):
    ?>
      <img src="<?php echo esc_url($whyus_img['url']); ?>" alt="<?php echo esc_attr($whyus_img['alt']); ?>">
    <?php endif; ?>
  </div>

  <div class="container">
    <div class="section-heading">
      <h2><?php the_field('whyus_heading'); ?></h2>

      <div class="descpText">
        <p><?php the_field('whyus_description_1'); ?></p>
       
      </div>

      <div class="whyUsAwardsHolder d-flex align-items-center">
        <div class="awardsBadge">
          <?php 
            $awards_img = get_field('whyus_awards_image');
            if ($awards_img):
          ?>
            <img src="<?php echo esc_url($awards_img['url']); ?>" alt="<?php echo esc_attr($awards_img['alt']); ?>">
          <?php endif; ?>
        </div>

        <div class="clBtn">
          <a href="tel:<?php echo $theme_options['phone'];?>">
            <span><i class="las la-phone-volume"></i></span>
            <p>Call Us Now <strong><?php echo $theme_options['phone'];?></strong></p>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>
 

<section class="serviceAreaWrapper section-padding bgImage"
  style="background-image: url('<?php echo esc_url(get_field('service_area_background')['url']); ?>');">
  <div class="container">
    <div class="section-heading text-center mb-50">
      <h2><?php the_field('service_area_heading'); ?></h2>
    </div>
    <div class="row">
      <?php if( have_rows('service_areas') ): ?>
        <?php while( have_rows('service_areas') ): the_row(); 
          $img = get_sub_field('area_image');
          $name = get_sub_field('area_name');
        ?>
        <div class="col col-5-custom">
          <div class="serviceAreaCard">
            <figure>
              <?php if ($img): ?>
                <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>">
              <?php endif; ?>
            </figure>
            <h3><?php echo esc_html($name); ?></h3>
          </div>
        </div>
        <?php endwhile; ?>
      <?php endif; ?>
    </div>
  </div>
</section>


<!-- awnings-styles -->
<section class="awningsStylesWrapper bgImage section-padding"
     style="background-image: url('<?php echo esc_url(get_field('awning_styles_bg')['url']); ?>');">
    <div class="container">
        <div class="section-heading text-center mb-50 isLight">
            <h2><?php the_field('awning_styles_heading'); ?></h2>
        </div>
        <div class="row">
            <?php if (have_rows('awning_styles')) : ?>
                <?php while (have_rows('awning_styles')) : the_row();
                    $icon = get_sub_field('icon');
                    $title = get_sub_field('title');
                    $link = get_sub_field('link');
                ?>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="awningsStylesCard">
                            <a href="<?php echo esc_url($link ?: '#'); ?>">
                                <figure>
                                    <?php if ($icon) : ?>
                                        <img src="<?php echo esc_url($icon['url']); ?>" alt="<?php echo esc_attr($title); ?>">
                                    <?php endif; ?>
                                </figure>
                                <p><?php echo esc_html($title); ?></p>
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<!-- awnings-styles -->

<!-- our-project -->
<section class="ourProjectWrapper section-padding">
  <div class="container">
    <div class="section-heading mb-50">
      <div class="d-flex justify-content-between align-items-center  flex-wrap">
        <div class="dataLeft col-lg-6 col-12">
          <h2><?php the_field('project_section_title'); ?></h2>
        </div>
        <div class="dataRight col-lg-5 col-12">
          <p><?php the_field('project_section_description'); ?></p>
        </div>
      </div>
    </div>
  </div>

  <div class="projectSliderOuter">
    <div class="swiper">
      <div class="swiper-wrapper">
        <?php if( have_rows('projects_list') ): ?>
          <?php while( have_rows('projects_list') ): the_row(); 
            $image = get_sub_field('project_image');
            $title = get_sub_field('project_title');
            $description = get_sub_field('project_description');
            $link = get_sub_field('project_link');
          ?>
          <div class="swiper-slide">
            <div class="projectSliderCard">
              <figure>
                <?php if($image): ?>
                  <img src="<?php echo esc_url($image['url']); ?>" alt="<?php echo esc_attr($title); ?>">
                <?php endif; ?>
              </figure>
              <div class="data">
                <?php if($link): ?>
                  <a href="<?php echo esc_url($link); ?>" target="_blank">
                    <h3><?php echo esc_html($title); ?></h3>
                  </a>
                <?php else: ?>
                  <h3><?php echo esc_html($title); ?></h3>
                <?php endif; ?>
                <p><?php echo esc_html($description); ?></p>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        <?php endif; ?>
      </div>
    </div>
    <div class="swiper-pagination"></div>
  </div>

  <div class="divider"></div>
</section>
<!-- our-project -->

<!-- our-showroom -->
<section class="ourShowroomWrapper section-padding">
  <div class="container">
    <div class="row justify-content-between">
      
      <!-- Left Side: Showroom Gallery -->
      <div class="col-lg-5 col-md-6">
        <div class="section-heading mb-5">
          <h2><?php the_field('showroom_section_title'); ?></h2>
        </div>
        
        <div class="ourShowroomSlider p_r">
          <div class="swiper">
            <div class="swiper-wrapper">
              <?php if (have_rows('showroom_gallery')): ?>
                <?php while (have_rows('showroom_gallery')): the_row();
                  $image = get_sub_field('showroom_image');
                ?>
                <div class="swiper-slide">
                  <div class="ourShowroomCard">
                    <?php if ($image): ?>
                      <img src="<?php echo esc_url($image['url']); ?>" alt="">
                    <?php endif; ?>
                  </div>
                </div>
                <?php endwhile; ?>
              <?php endif; ?>
            </div>
          </div>
         <!-- Add Pagination -->
                <div class="swiper-pagination"></div>
        </div>
      </div>

      <!-- Right Side: Showroom Map -->
      <div class="col-lg-7 col-md-6">
       <?php 
$map_iframe = get_field('showroom_map_embed');
if ($map_iframe): ?>
  <div class="showroomMaps ps-lg-5 ps-sm-0">
    <?php echo $map_iframe; ?>
  </div>
<?php endif; ?>
      </div>

    </div>
  </div>
</section>
<!-- our-showroom -->



<section class="getInTouchWrapper">
  <?php 
  $bg_image = get_field('get_in_touch_bg');
  $heading = get_field('get_in_touch_heading');
  $desc    = get_field('get_in_touch_text');
  ?>
  <div class="bg-image-section" style="background-image: url(<?php echo esc_url($bg_image['url']); ?>);">
    <div class="container">
      <div class="section-heading text-center">
        <?php if ($heading): ?>
          <h2><?php echo esc_html($heading); ?></h2>
        <?php endif; ?>
        <?php if ($desc): ?>
          <p><?php echo esc_html($desc); ?></p>
        <?php endif; ?>
      </div>
    </div>
  </div>
        <div class="getInToucFormWrapper">
  <div class="container">
    <div class="newContactFormOuter">
      
        <?php echo do_shortcode('[contact-form-7 id="ecdc25c" title="home-form"]'); ?>
    </div>
  </div>
</div>

      </section>
      <!-- get-in-touch -->

<?php get_footer();?>