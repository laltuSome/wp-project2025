 
<?php global $theme_options;?>


<!-- footer-area -->
    <footer class="footer-wrapper">

      <div class="container">

        <div class="row footer-top-row">
          <div class="col">
            <!-- footer-widget -->
            <div class="footer-widget">
              <div class="footer-logo">
               <a class="logo-footer" href="<?php echo home_url();?>" >
<img src="<?php echo $theme_options['footer-logo']['url'];?>" alt="Logo" width="127" height="139">
</a>
              </div>

              <div class="licText">
                <p>Contractors License # 640132</p>
              </div>
            </div>
            <!-- footer-widget -->
          </div>
          <div class="col">
            <!-- footer-widget -->
            <div class="footer-widget">

              <div class="footer-widget-title">
                <p>connect with us</p>
              </div>
              <div class="footer-contact-list">
                <ul>
                  <li>
                    <span><i class="las la-map-marker"></i></span>
                    <a href="https://maps.app.goo.gl/GmWx8TtWtq5Kqxna7" target="_blank"> <?php echo $theme_options['footer-address']; ?></a>
                  </li>
                  <li>
                    <span><i class="las la-phone-volume"></i></span>
                    <a href="tel:<?php echo $theme_options['phone']; ?>"> <?php echo $theme_options['phone']; ?></a>
                  </li>

                </ul>
              </div>
              <!-- social-links -->
              <ul class="footer-social">
          

<li><a href="<?php echo $theme_options['social-yelp'];?>" title="yelp">
<i class="lab la-yelp"></i>
</a></li>

<li><a href="<?php echo $theme_options['social-facebook'];?>"  title="facebook">
<i class="lab la-facebook-f"></i>
</a></li>

<li><a href="<?php echo $theme_options['social-instagram'];?>"  title="instagram">
<i class="lab la-instagram"></i>
</a></li>

              </ul>
              <!-- social-links -->
            </div>
            <!-- footer-widget -->
          </div>


          <div class="col">
            <!-- footer-widget -->
            <div class="footer-widget">
              <div class="footer-widget-title">
                <p>Important Links</p>
              </div>
              <div class="footer-links">
             <ul class="footer-menu">
   <?php
$args = array(
'theme_location'   => '',
'menu'         => 'Footer Menu',
'container'      => '',
'container_class'  => '',
'container_id'     => '',
'menu_class'     => 'menu',
'menu_id'      => 'menu-footer',
'echo'         => true,
'fallback_cb'    => 'wp_page_menu',
'before'       => '',
'after'        => '',
'link_before'    => '',
'link_after'     => '',
'items_wrap'     => '%3$s',
'depth'        => 0,
'walker'       => '' );
?>
              <?php wp_nav_menu( $args ); ?>
</ul>
              </div>
            </div>
            <!-- footer-widget -->
          </div>
          <div class="col">
            <!-- footer-widget -->
            <div class="footer-widget">
              <div class="footer-widget-title">
                <p>Projects</p>
              </div>
              <div class="footer-links">
               <ul class="footer-menu">
   <?php
$args = array(
'theme_location'   => '',
'menu'         => 'project',
'container'      => '',
'container_class'  => '',
'container_id'     => '',
'menu_class'     => 'menu',
'menu_id'      => 'menu-prject',
'echo'         => true,
'fallback_cb'    => 'wp_page_menu',
'before'       => '',
'after'        => '',
'link_before'    => '',
'link_after'     => '',
'items_wrap'     => '%3$s',
'depth'        => 0,
'walker'       => '' );
?>
              <?php wp_nav_menu( $args ); ?>
</ul>
              </div>
            </div>
            <!-- footer-widget -->
          </div>
          <div class="col">
            <div class="footerMap">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3299.370837942364!2d-118.36227542481588!3d34.21354840919659!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2944568aa91e5%3A0xd47d913ca646bbf4!2s7830%20San%20Fernando%20Rd%2C%20Sun%20Valley%2C%20CA%2091352%2C%20USA!5e0!3m2!1sen!2sin!4v1749167204025!5m2!1sen!2sin"
                style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>

        </div>
      </div>
      <!-- footer-bottom-information -->
      <div class="footer-bottom-row">
        <div class="container">
          <div class="holder">
            <!-- copyright -->
            <div class="copyright-text text-center">
                <p class="text-copy">© <?php echo date('Y'); ?> |  <?php bloginfo('name'); ?>, All Rights Reserved.</p>
            </div>
            <!-- copyright -->
          </div>
        </div>
      </div>
      <!-- footer-bottom-information -->
    </footer>
    <!-- footer-area -->




    


<?php wp_footer(); ?>
</body>
</html>
